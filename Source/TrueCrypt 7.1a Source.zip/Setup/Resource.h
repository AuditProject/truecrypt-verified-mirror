//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Setup.rc
//
#define IDR_COMREG                      10
#define IDD_INSTALL                     101
#define IDD_INSTALL_OPTIONS_PAGE_DLG    102
#define IDD_UNINSTALL                   103
#define IDI_SETUP                       104
#define IDR_SETUP_RSRC_HEADER           105
#define IDD_EXTRACTION_OPTIONS_PAGE_DLG 106
#define IDB_SETUP_WIZARD                107
#define IDD_INTRO_PAGE_DLG              108
#define IDB_SETUP_WIZARD_BKG            109
#define IDD_INFO_PAGE_DLG               110
#define IDD_INSTL_DLG                   111
#define IDD_WIZARD_MODE_PAGE_DLG        112
#define IDD_PROGRESS_PAGE_DLG           113
#define IDD_DONATIONS_PAGE_DLG          114
#define IDC_DESTINATION                 1000
#define IDC_BOX_TITLE                   1001
#define IDC_BROWSE                      1002
#define IDC_BOX_INFO                    1003
#define IDC_LICENSE                     1004
#define IDC_BOX_HELP                    1005
#define IDC_LICENSE_TEXT                1006
#define IDC_BOX_HELP2                   1007
#define IDC_FILE_TYPE                   1008
#define IDT_UNINSTALL_DIR               1009
#define IDC_PROG_GROUP                  1010
#define IDC_SYSTEM_RESTORE              1011
#define IDC_DESKTOP_ICON                1012
#define IDC_ALL_USERS                   1013
#define IDT_INSTALL_DESTINATION         1014
#define IDC_UNINSTALL                   1015
#define IDC_PROGRESS_BAR                1016
#define IDC_LOG_WINDOW                  1017
#define IDC_SETUP_WIZARD_BKG            1018
#define IDC_SETUP_WIZARD_GFX_AREA       1019
#define IDC_HR                          1020
#define IDC_OPEN_CONTAINING_FOLDER      1021
#define IDC_AGREE                       1022
#define IDC_HR_BOTTOM                   1023
#define IDC_WIZARD_MODE_INSTALL         1024
#define IDC_WIZARD_MODE_EXTRACT_ONLY    1025
#define IDC_NEXT                        1026
#define IDC_PREV                        1027
#define IDT_EXTRACT_DESTINATION         1028
#define IDC_POS_BOX                     1029
#define IDC_BITMAP_SETUP_WIZARD         1030
#define IDC_MAIN_CONTENT_CANVAS         1031
#define IDC_DONATE                      1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
